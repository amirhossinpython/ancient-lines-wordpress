<?php
class Ancient_Timeline {
    public function __construct() {
        add_action('wp_footer', [$this, 'render_timeline']);
    }
    
    public function render_timeline() {
        $position = get_theme_mod('ancient_timeline_position', 'bottom');
        if ($position === 'hidden') return;
        
        $script = get_theme_mod('ancient_timeline_script', 'pahlavi');
        $date = date_i18n('Y/m/d - H:i:s');
        
        $converter = new Ancient_Converter();
        $ancient_date = $converter->convert($date, $script);
        
        echo '<div class="ancient-timeline" style="position:fixed; ' . $position . ':0; left:0; right:0; background:#1a1a2e; color:#c9a03d; text-align:center; padding:10px; z-index:9999; font-size:14px;">';
        echo '🏛️ ' . $ancient_date;
        echo '</div>';
    }
}