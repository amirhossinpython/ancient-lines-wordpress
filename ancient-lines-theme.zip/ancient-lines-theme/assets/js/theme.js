// منو همبرگر
const toggle = document.getElementById('menuToggle');
const mobileMenu = document.getElementById('mobileMenu');
const overlay = document.getElementById('overlay');
const closeMenu = document.getElementById('closeMenu');

if (toggle && mobileMenu && overlay) {
    toggle.addEventListener('click', () => {
        mobileMenu.classList.add('open');
        overlay.style.display = 'block';
    });
    const close = () => {
        mobileMenu.classList.remove('open');
        overlay.style.display = 'none';
    };
    closeMenu.addEventListener('click', close);
    overlay.addEventListener('click', close);
}

// تایم‌لاین
if (typeof ancientTimelinePos !== 'undefined') {
    const pos = ancientTimelinePos;
    const timeline = document.querySelector('.ancient-timeline');
    if (timeline) {
        timeline.classList.add('timeline-' + pos);
    }
}