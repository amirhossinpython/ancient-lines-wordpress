<?php get_header(); ?>

<div class="container">
    <div class="converter-form">
        <h2 style="text-align:center; color:var(--primary-color);">🏛️ تبدیل متن به خطوط باستانی</h2>
        
        <form id="ancient-convert-form" method="post">
            <textarea name="ancient_text" id="ancient_text" rows="4" placeholder="متن خود را وارد کنید..."></textarea>
            
            <select name="ancient_script" id="ancient_script">
                <option value="cuneiform">میخی (Cuneiform)</option>
                <option value="pahlavi">پهلوی (Pahlavi)</option>
                <option value="runic">رونی (Runic)</option>
                <option value="elamite">عیلامی (Elamite)</option>
                <option value="phoenician">فنیقی (Phoenician)</option>
                <option value="avestan">اوستایی (Avestan)</option>
                <option value="hieroglyph">هیروگلیف (Hieroglyph)</option>
                <option value="akkadian">اکدی (Akkadian)</option>
                <option value="brahmi">براهمی (Brahmi)</option>
                <option value="kharosthi">خروشتی (Kharosthi)</option>
                <option value="linear_b">خط B (Linear B)</option>
                <option value="manichaean">منیایی (Manichaean)</option>
                <option value="oracle_bone">اوراکل بون (Oracle Bone)</option>
                <option value="sanskrit">سانسکریت (Sanskrit)</option>
                <option value="hebrew">عبری (Hebrew)</option>
            </select>
            
            <button type="submit" name="ancient_submit" id="convert_btn">✨ تبدیل به خط باستانی</button>
        </form>
        
        <div id="result_box" class="result-box" style="display:none;">
            <div id="result_text"></div>
        </div>
    </div>
</div>

<?php
// پردازش فرم (در PHP، نه جاوااسکریپت)
if (isset($_POST['ancient_submit'])) {
    $text = sanitize_text_field($_POST['ancient_text']);
    $script = sanitize_text_field($_POST['ancient_script']);
    
    if ($text) {
        $converter = new Ancient_Converter();
        $result = $converter->convert($text, $script);
        echo '<script>
            document.getElementById("result_text").innerHTML = ' . json_encode($result) . ';
            document.getElementById("result_box").style.display = "block";
        </script>';
    }
}
?>

<?php get_footer(); ?>