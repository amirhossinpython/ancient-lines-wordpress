<!DOCTYPE html>
<html <?php language_attributes(); ?> dir="rtl">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
    <style>
        :root {
            --primary-color: <?php echo esc_attr(get_theme_mod('primary_color', '#c9a03d')); ?>;
            --bg-color: <?php echo esc_attr(get_theme_mod('bg_color', '#0a0a0f')); ?>;
            --text-color: <?php echo esc_attr(get_theme_mod('text_color', '#e8dcc8')); ?>;
            --bg-light: <?php echo esc_attr(get_theme_mod('secondary_bg', '#1a1a2e')); ?>;
        }
    </style>
</head>
<body <?php body_class(); ?>>

<header class="site-header">
    <div class="container">
        <h1 class="site-title">
            <a href="<?php echo home_url(); ?>">🏛️ <?php bloginfo('name'); ?></a>
        </h1>
    </div>
</header>

<main>