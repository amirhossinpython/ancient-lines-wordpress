<?php
class Ancient_Converter {
    // آدرس مستقیم وب سرویس پایتون
    private $api_url = 'http://localhost:5001/convert';
    
    public function convert($text, $script = 'cuneiform') {
        // افزایش تایم‌اوت به 60 ثانیه
        $response = wp_remote_post($this->api_url, [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => json_encode(['text' => $text, 'script' => $script]),
            'timeout' => 60,
        ]);
        
        if (is_wp_error($response)) {
            return '❌ خطا: ' . $response->get_error_message();
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['success']) && $data['success'] === true) {
            return $data['result'];
        }
        
        return '❌ ' . ($data['error'] ?? 'خطا در تبدیل');
    }
}