<?php
/**
 * Plugin Name: Ancient Lines of the World
 * Version: 1.0.0
 * Author: Amir Hossein Khazaei
 */

if (!defined('ABSPATH')) exit;

define('ANCIENT_PLUGIN_DIR', plugin_dir_path(__FILE__));

require_once ANCIENT_PLUGIN_DIR . 'includes/class-converter.php';
require_once ANCIENT_PLUGIN_DIR . 'includes/class-timeline.php';
require_once ANCIENT_PLUGIN_DIR . 'includes/class-api.php';

add_action('init', function() {
    new Ancient_Converter();
    new Ancient_Timeline();
});

// منوی ادمین
add_action('admin_menu', function() {
    add_menu_page('Ancient Lines', '🏛️ Ancient Lines', 'manage_options', 'ancient-lines', 'ancient_settings_page', 'dashicons-text-page', 80);
});

function ancient_settings_page() {
    ?>
    <div class="wrap">
        <h1>🏛️ Ancient Lines of the World</h1>
        <form method="post" action="options.php">
            <?php settings_fields('ancient_settings_group'); do_settings_sections('ancient-lines'); submit_button(); ?>
        </form>
    </div>
    <?php
}

add_action('admin_init', function() {
    register_setting('ancient_settings_group', 'ancient_default_script');
    add_settings_section('ancient_main_section', 'تنظیمات اصلی', null, 'ancient-lines');
    add_settings_field('ancient_default_script', 'خط پیش‌فرض', function() {
        $value = get_option('ancient_default_script', 'cuneiform');
        echo '<select name="ancient_default_script">';
        echo '<option value="cuneiform"' . selected($value, 'cuneiform', false) . '>میخی</option>';
        echo '<option value="pahlavi"' . selected($value, 'pahlavi', false) . '>پهلوی</option>';
        echo '<option value="runic"' . selected($value, 'runic', false) . '>رونی</option>';
        echo '<option value="elamite"' . selected($value, 'elamite', false) . '>عیلامی</option>';
        echo '<option value="phoenician"' . selected($value, 'phoenician', false) . '>فنیقی</option>';
        echo '<option value="avestan"' . selected($value, 'avestan', false) . '>اوستایی</option>';
        echo '</select>';
    }, 'ancient_main_section', 'ancient_default_script');
});

// شورت‌کد
add_shortcode('ancient', function($atts) {
    $atts = shortcode_atts(['text' => '', 'script' => get_option('ancient_default_script', 'cuneiform')], $atts);
    if (empty($atts['text'])) return '';
    $converter = new Ancient_Converter();
    return $converter->convert($atts['text'], $atts['script']);
});