/**
 * شخصی‌سازی زنده (Live Preview)
 */
(function($) {
    wp.customize('primary_color', function(value) {
        value.bind(function(newval) {
            $(':root').css('--primary-color', newval);
            $(':root').css('--primary-dark', newval + 'cc');
        });
    });
    wp.customize('bg_color', function(value) {
        value.bind(function(newval) {
            $(':root').css('--bg-color', newval);
        });
    });
    wp.customize('text_color', function(value) {
        value.bind(function(newval) {
            $(':root').css('--text-color', newval);
        });
    });
    wp.customize('secondary_bg', function(value) {
        value.bind(function(newval) {
            $(':root').css('--bg-light', newval);
        });
    });
})(jQuery);