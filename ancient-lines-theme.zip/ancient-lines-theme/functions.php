<?php
add_theme_support('custom-logo');
add_theme_support('post-thumbnails');
add_theme_support('title-tag');

// استایل قالب
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('ancient-theme', get_stylesheet_uri(), [], '1.0.0');
});

// اسکریپت شخصی‌سازی (فقط در بخش Customizer)
add_action('customize_preview_init', function() {
    wp_enqueue_script('ancient-customizer', get_template_directory_uri() . '/assets/js/customizer.js', ['jquery', 'customize-preview'], '1.0.0', true);
});

// منوها
register_nav_menus([
    'primary' => 'منوی اصلی',
    'footer' => 'منوی فوتر',
]);

// شخصی‌سازی
require_once get_template_directory() . '/inc/customizer.php';