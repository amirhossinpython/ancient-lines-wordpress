</main>

<footer class="site-footer">
    <div class="container">
        <p>© <?php echo date('Y'); ?> <?php bloginfo('name'); ?> | ساخته شده با ❤️ توسط امیرحسین خزاعی</p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>