<?php
add_action('rest_api_init', function() {
    register_rest_route('ancient/v1', '/convert', [
        'methods' => 'POST',
        'callback' => 'ancient_rest_convert',
        'permission_callback' => '__return_true',
    ]);
});

function ancient_rest_convert($request) {
    $params = $request->get_json_params();
    $text = $params['text'] ?? '';
    $script = $params['script'] ?? 'cuneiform';
    
    if (empty($text)) {
        return ['success' => false, 'error' => 'متن وارد نشده'];
    }
    
    $converter = new Ancient_Converter();
    $result = $converter->convert($text, $script);
    
    // اگر نتیجه با ❌ شروع شود، خطاست
    if (strpos($result, '❌') === 0) {
        return ['success' => false, 'error' => $result];
    }
    
    return ['success' => true, 'result' => $result];
}