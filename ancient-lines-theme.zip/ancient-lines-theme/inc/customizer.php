<?php
add_action('customize_register', function($wp_customize) {
    
    // ========== بخش رنگ‌ها ==========
    $wp_customize->add_section('ancient_colors', [
        'title' => '🎨 رنگ‌ها',
        'priority' => 30,
    ]);
    
    // رنگ اصلی
    $wp_customize->add_setting('primary_color', [
        'default' => '#c9a03d',
        'transport' => 'postMessage',
    ]);
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'primary_color', [
        'label' => 'رنگ اصلی (دکمه‌ها، لینک‌ها)',
        'section' => 'ancient_colors',
    ]));
    
    // رنگ پس‌زمینه
    $wp_customize->add_setting('bg_color', [
        'default' => '#0a0a0f',
        'transport' => 'postMessage',
    ]);
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'bg_color', [
        'label' => 'رنگ پس‌زمینه',
        'section' => 'ancient_colors',
    ]));
    
    // رنگ متن
    $wp_customize->add_setting('text_color', [
        'default' => '#e8dcc8',
        'transport' => 'postMessage',
    ]);
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'text_color', [
        'label' => 'رنگ متن',
        'section' => 'ancient_colors',
    ]));
    
    // رنگ پس‌زمینه ثانویه
    $wp_customize->add_setting('secondary_bg', [
        'default' => '#1a1a2e',
        'transport' => 'postMessage',
    ]);
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'secondary_bg', [
        'label' => 'رنگ پس‌زمینه ثانویه',
        'section' => 'ancient_colors',
    ]));
    
    // ========== بخش تایم‌لاین ==========
    $wp_customize->add_section('ancient_timeline', [
        'title' => '⏳ تایم‌لاین',
        'priority' => 40,
    ]);
    
    $wp_customize->add_setting('timeline_position', [
        'default' => 'bottom',
        'transport' => 'refresh',
    ]);
    $wp_customize->add_control('timeline_position', [
        'label' => 'موقعیت تایم‌لاین',
        'section' => 'ancient_timeline',
        'type' => 'select',
        'choices' => [
            'top' => 'بالا',
            'bottom' => 'پایین',
            'hidden' => 'مخفی',
        ],
    ]);
    
    $wp_customize->add_setting('timeline_script', [
        'default' => 'pahlavi',
        'transport' => 'refresh',
    ]);
    $wp_customize->add_control('timeline_script', [
        'label' => 'خط تایم‌لاین',
        'section' => 'ancient_timeline',
        'type' => 'select',
        'choices' => [
            'cuneiform' => 'میخی',
            'pahlavi' => 'پهلوی',
            'runic' => 'رونی',
            'elamite' => 'عیلامی',
            'phoenician' => 'فنیقی',
        ],
    ]);
});